package com.wipro.boxing;

//public class Test {
//
//	int a, b;
//	a=5;
//	c =7;
//}
