package com.wipro.intf;

final class Admin {
	void show() {
		
	}
}

class Prasanna extends Admin {
	
}
public class FinalEx {

}
