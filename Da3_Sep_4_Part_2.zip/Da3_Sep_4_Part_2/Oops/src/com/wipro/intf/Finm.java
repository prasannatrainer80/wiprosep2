package com.wipro.intf;

class First {
	final void show() {
		
	}
}

class Second extends First {
	void show() {
		
	}
}
public class Finm {

}
