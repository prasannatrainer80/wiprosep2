package com.wipro.conex;

public class ConEmploy {

	public static void main(String[] args) {
		Employ e1 = new Employ(56, "Vipul", 99423.44);
		System.out.println(e1);
		
		Employ e2 = new Employ(86, "Archana", 88844.74);
		System.out.println(e2);
	}
}
