package com.wipro.ex;

public class VotingException extends Exception {

	VotingException(String error) {
		super(error);
	}
}
