package com.wipro.ex;

public class NumberZeroException extends Exception {

	NumberZeroException(String error) {
		super(error);
	}
}
