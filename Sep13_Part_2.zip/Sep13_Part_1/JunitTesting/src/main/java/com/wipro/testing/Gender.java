package com.wipro.testing;

public enum Gender {
	MALE, FEMALE
}
