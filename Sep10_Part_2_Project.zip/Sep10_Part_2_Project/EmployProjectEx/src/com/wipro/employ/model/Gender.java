package com.wipro.employ.model;

public enum Gender {
	MALE, FEMALE
}
