package com.wipro.jsp;

public enum Gender {
	MALE, FEMALE
}
