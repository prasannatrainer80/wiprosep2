select * from customer;

select * from customer where cus_Id=1;

-- Add Customer

-- select * from Menu

-- select * from Menu where MEN_ID=1;
-- add Menu
-- Authenticate Customer 

select count(*) cnt from customer where cus_username='prassucp'
and cus_password='hexaware@';