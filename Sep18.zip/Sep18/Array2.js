function show() {
    var names = new Array("Kshama","Archana","subbarayudu","Ajinkya","Kalpana");
    for(var v in names) {
        document.writeln(names[v] + "<br/>");
    }
}