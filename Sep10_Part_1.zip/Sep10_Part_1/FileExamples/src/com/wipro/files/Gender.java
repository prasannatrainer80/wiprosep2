package com.wipro.files;

public enum Gender {
	MALE, FEMALE
}
