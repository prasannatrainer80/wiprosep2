package com.wipro.test;

public enum Gender {
	MALE, FEMALE
}
