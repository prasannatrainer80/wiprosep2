package com.wipro.test;

public class EmployExample {

	public static void main(String[] args) {
		Employ employ = new Employ(1, "Prasanna", Gender.MALE, "Java", "Trainer", 94923.44);
		System.out.println(employ);
	}
}
