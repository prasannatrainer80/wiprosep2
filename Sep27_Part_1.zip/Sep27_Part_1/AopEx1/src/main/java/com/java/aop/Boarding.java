package com.java.aop;

public class Boarding {
	
	public void assignProject() {
		System.out.println("We share Manager details soon...Please Connect with him");
	}
	
}
