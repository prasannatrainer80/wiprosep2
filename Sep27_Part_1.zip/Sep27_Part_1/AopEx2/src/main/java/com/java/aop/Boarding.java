package com.java.aop;

public class Boarding {

	public void assignProject(String employ) {
		System.out.println("Mr/Ms "+employ + " Please Meet Relevant Manager we messaged");
	}
	
	public void location() {
		System.out.println("It Bangalore/Hyderbad...");
	}
	public void company() {
		System.out.println("Its Wipro...");
	}
}
