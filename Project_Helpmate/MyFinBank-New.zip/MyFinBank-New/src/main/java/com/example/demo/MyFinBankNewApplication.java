package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyFinBankNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyFinBankNewApplication.class, args);
	}

}
