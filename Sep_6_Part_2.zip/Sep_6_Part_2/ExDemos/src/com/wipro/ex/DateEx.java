package com.wipro.ex;

import java.sql.Date;
import java.text.SimpleDateFormat;

public class DateEx {

	public static void main(String[] args) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String strDate;
	}
}
