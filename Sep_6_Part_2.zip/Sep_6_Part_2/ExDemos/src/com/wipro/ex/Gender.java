package com.wipro.ex;

public enum Gender {
	MALE, FEMALE
}
