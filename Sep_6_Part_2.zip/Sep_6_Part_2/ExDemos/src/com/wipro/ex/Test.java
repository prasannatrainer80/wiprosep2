package com.wipro.ex;

public class Test {

	int a;
	Test(int a) {
		this.a = a;
	}
}
