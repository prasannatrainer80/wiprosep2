package com.wipro.jdbc;

public enum Gender {

	MALE, FEMALE
}
