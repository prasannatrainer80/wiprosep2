package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActuatorSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActuatorSecurityApplication.class, args);
	}

}
