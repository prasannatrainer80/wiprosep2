package com.wipro.collections;

import java.util.HashSet;
import java.util.Set;

public class SetExample1 {

	public static void main(String[] args) {
		Set names = new HashSet();
		names.add("Mounika");
		names.add("Aditya");
		names.add("Vipul");
		names.add("Lavanya");
		names.add("Muhammed");
		names.add("Kalpana");
		names.add("Tarak");
		names.add("Simran");
		names.add("Aditya");
		names.add("Vipul");
		names.add("Lavanya");
		names.add("Muhammed");
		names.add("Kalpana");
		names.add("Tarak");
		names.add("Aditya");
		names.add("Vipul");
		names.add("Lavanya");
		names.add("Muhammed");
		names.add("Kalpana");
		names.add("Tarak");
		names.add("Aditya");
		names.add("Vipul");
		names.add("Lavanya");
		names.add("Muhammed");
		names.add("Kalpana");
		names.add("Tarak");
		names.add("Simran");
		names.add("Aditya");
		names.add("Vipul");
		names.add("Lavanya");
		names.add("Muhammed");
		names.add("Kalpana");
		names.add("Tarak");
		names.add("Simran");
		System.out.println("HashSet Data is  ");
		for (Object object : names) {
			System.out.println(object);
		}
	}
}
