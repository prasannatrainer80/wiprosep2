package com.wipro.p1;

public class Data {

	public void show() {
		Demo demo = new Demo();
		System.out.println(demo.publicGreeting);
		System.out.println(demo.protectedGreeting);
		System.out.println(demo.friendlyGreeting);
	}
}
