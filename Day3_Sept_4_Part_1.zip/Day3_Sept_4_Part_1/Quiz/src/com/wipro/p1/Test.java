package com.wipro.p1;

public class Test extends Demo {

	public void show() {
		Test test = new Test();
		System.out.println(test.publicGreeting);
		System.out.println(test.friendlyGreeting);
		System.out.println(test.protectedGreeting);
	}
}
