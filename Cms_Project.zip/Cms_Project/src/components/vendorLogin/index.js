import vendorLogin from "./vendorLogin"
export default vendorLogin;
