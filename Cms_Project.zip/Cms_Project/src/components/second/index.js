import second from "./second"
export default second;
