package com.wipro.demo;

public class ArrayExample2 {

	public static void main(String[] args) {
		String[] names = new String[] {
			"Ajinkya","Aditya",
			"Khushi", "Subbarayudu",
			"Usha"
		};
		
		for (String s : names) {
			System.out.println(s);
		}
	}
}
