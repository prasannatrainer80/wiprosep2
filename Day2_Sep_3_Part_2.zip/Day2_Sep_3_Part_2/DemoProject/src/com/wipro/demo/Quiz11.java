package com.wipro.demo;

public class Quiz11 {

	public static void main(String[] args) {
		String str = "Hello";
		String res = str.concat(" World");
		System.out.println(str);
		System.out.println(res);
	}
}
