package com.wipro.demo;

public class Quiz5 {

	public static void main(String[] args) {
		int a = 5, b;
		if (a > 5 || a < 5) {
			b = 10;
		} else {
			b = 7;
		}
		System.out.println(b);
	}
}
