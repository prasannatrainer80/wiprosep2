package com.wipro.demo;

public class Quiz6 {

	public static void main(String[] args) {
		boolean flag = true;
		int x=0;
		flag = x > 5;
		System.out.println(flag);
	}
}
