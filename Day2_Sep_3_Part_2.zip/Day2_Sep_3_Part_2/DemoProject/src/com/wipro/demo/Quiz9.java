package com.wipro.demo;

public class Quiz9 {

	public static void main(String[] args) {
//		int x=10;
//		int y = x++ + x++;
//		System.out.println(y);
		int x = 10;
		int y = ++x + ++x;
		System.out.println(y);
	}
}
