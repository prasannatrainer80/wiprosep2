package com.wipro.demo;

public class Quiz2 {

	public static void main(String[] args) {
		int a = 10, b= 20, c=30;
		String str = "sam";
		System.out.println(a+b+c+str);
		System.out.println(a+b+str+c);
		System.out.println(str+a+b+c);
		
	}
}
