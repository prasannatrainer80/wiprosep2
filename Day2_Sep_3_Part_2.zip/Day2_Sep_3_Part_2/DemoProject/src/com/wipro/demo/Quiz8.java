package com.wipro.demo;

public class Quiz8 {

	public static void main(String[] args) {
		int x=12;
		System.out.println(++x);
	}
}
