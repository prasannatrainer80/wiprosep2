package com.wipro.demo;

public class Quiz4 {

	public static void main(String[] args) {
		while(true) {
			System.out.println("Hi");
		}
	}
}
