package com.wipro.demo;

public class Quiz12 {

	public static void main(String[] args) {
		String s1="Lavanya", s2="Khushi", s3="Aditya", s4="Lavanya";
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		System.out.println(s4.hashCode());
	}
}
