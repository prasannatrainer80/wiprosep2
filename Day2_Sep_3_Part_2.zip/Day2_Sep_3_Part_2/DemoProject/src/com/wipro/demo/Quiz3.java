package com.wipro.demo;

public class Quiz3 {

	public static void main(String[] args) {
		int i = 9;
		while (i < 10) {
			System.out.println("Hi");
			i--;
		}
	}
}


