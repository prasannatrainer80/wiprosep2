package com.wipro.demo;

/**
 * Program to display min. of 3 numbers
 */

public class Min3 {

}
