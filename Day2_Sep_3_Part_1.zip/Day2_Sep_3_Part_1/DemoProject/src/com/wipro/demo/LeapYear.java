package com.wipro.demo;

/**
 * Program to check the given year is leap year or not
 */


public class LeapYear {

}
