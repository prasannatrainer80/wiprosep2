package com.wipro.demo;

public class LoopExample1 {

	public static void main(String[] args) {
		int n = 10;
		int i =0;
		
		while(i < n) {
			System.out.println("Hi I am Lavanya...");
			i++;
		}
	}
}
