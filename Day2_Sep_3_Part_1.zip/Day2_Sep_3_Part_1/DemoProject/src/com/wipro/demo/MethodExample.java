package com.wipro.demo;

public class MethodExample {

	public void greeting() {
		System.out.println("Good Morning...");
	}
	
	public static void main(String[] args) {
		// class_name obj = new class_name();
		MethodExample obj1 = new MethodExample();
		obj1.greeting();
	}
}
